import requests
import mysql.connector
from datetime import datetime
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

API_KEY = os.getenv('API_KEY')
DB_HOST = os.getenv('DB_HOST')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME')

# Debugging output
print("Environment Variables Loaded:")
print(f"API_KEY: {API_KEY}")
print(f"DB_HOST: {DB_HOST}")
print(f"DB_USER: {DB_USER}")
print(f"DB_PASSWORD: {DB_PASSWORD}")
print(f"DB_NAME: {DB_NAME}")

def fetch_weather():
    url = f'http://api.openweathermap.org/data/2.5/weather?q=Gdansk,pl&appid={API_KEY}&units=metric'
    response = requests.get(url)
    return response.json()

def store_weather_data(data):
    # Debugging output
    print("Attempting to connect to the database with the following parameters:")
    print(f"Host: {DB_HOST}")
    print(f"User: {DB_USER}")
    print(f"Database: {DB_NAME}")

    try:
        db = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        print("Database connection successful")

        cursor = db.cursor()

        # Drop the table if it exists and create a new one
        cursor.execute("DROP TABLE IF EXISTS weather")
        cursor.execute("""
        CREATE TABLE weather (
            id INT AUTO_INCREMENT PRIMARY KEY,
            city VARCHAR(100),
            description VARCHAR(255),
            temperature FLOAT,
            humidity INT,
            timestamp DATETIME
        )
        """)

        cursor.execute("""
        INSERT INTO weather (city, description, temperature, humidity, timestamp) 
        VALUES (%s, %s, %s, %s, %s)
        """, (
            data["name"],
            data["weather"][0]["description"],
            data["main"]["temp"],
            data["main"]["humidity"],
            datetime.now()
        ))

        db.commit()
        cursor.close()
        db.close()
        print("Weather data stored successfully")
    except mysql.connector.Error as err:
        print(f"Error: {err}")

if __name__ == "__main__":
    weather_data = fetch_weather()
    store_weather_data(weather_data)
    print("Weather data fetched and stored successfully.")
