from flask import Flask, render_template, request
import mysql.connector
from dotenv import load_dotenv
import os
import requests

# Load environment variables
load_dotenv()

DB_HOST = os.getenv('DB_HOST')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_NAME = os.getenv('DB_NAME')
API_KEY = os.getenv('API_KEY')

app = Flask(__name__)

def get_weather_data_from_api(city):
    url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return None

def store_weather_data(weather_data):
    try:
        db = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        cursor = db.cursor()
        cursor.execute("""
            INSERT INTO weather (city, description, temperature, humidity, timestamp)
            VALUES (%s, %s, %s, %s, NOW())
        """, (
            weather_data['name'],
            weather_data['weather'][0]['description'],
            weather_data['main']['temp'],
            weather_data['main']['humidity']
        ))
        db.commit()
        cursor.close()
        db.close()
    except mysql.connector.Error as err:
        print(f"Error: {err}")

@app.route('/', methods=['GET', 'POST'])
def index():
    weather_data = None
    city = 'Gdansk'  # Default city

    if request.method == 'POST':
        city = request.form.get('city')
        weather_data = get_weather_data_from_api(city)
        if weather_data:
            store_weather_data(weather_data)
    
    return render_template('index.html', weather=weather_data, city=city)

if __name__ == '__main__':
    app.run(debug=True)
