
CREATE DATABASE WeatherDB;

USE WeatherDB;

CREATE TABLE WeatherData (
    id INT AUTO_INCREMENT PRIMARY KEY,
    temperature FLOAT,
    pressure FLOAT,
    humidity FLOAT,
    wind_speed FLOAT,
    weather_description VARCHAR(255),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
